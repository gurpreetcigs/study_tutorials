import { Component } from '@angular/core';
import { Account } from './account/account.model';
import { AccountService, ACCOUNT_SERVICES_PROVIDERS } from './account/account.services';
import { LoggerService } from './util/logger.services';


@Component({
  selector: 'my-app',
  templateUrl: 'app/app.component.html'
  
})
export class AppComponent {
  
  private _nextId = 3;
  private _accounts:Array<Acccount>;
  private _accountServices:AccountService;
  
  constructor(accountService:AccountService){
    this._accountServices = accountService;
    this._accounts = this._accountServices.getAll();
  }
    /*private _accounts:Array<Acccount> = [
       new Account(1,"Bank of Baroda","My First account",500.10),
        new Account(2,"Bank asd","My secret account",1024.10) 
    ]*/
    private createAcc(newAccount:Account ){
      newAccount.id = this._nextId++;
      this._accountServices.createAccount(newAccount);
    }
    public removeAcc(index:number){ 
      console.log(index);
        this._accountServices.remove(index);
    }
  
  
}


/*
Copyright 2017 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://v2.angular.io/license
*/