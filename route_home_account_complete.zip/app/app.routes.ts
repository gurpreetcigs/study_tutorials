import { provideRouter, RouterConfig} from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AccountComponent } from './account/account.component';

export const routes: RouterConfig = [
    { path: ' ',component: HomeComponent },// localhost:3000/
    { path: 'accounts',component: AccountComponent}// localhost:3000/account
];

export const APP_ROUTER_PROVIDER = [
    provideRouter(routes)
]