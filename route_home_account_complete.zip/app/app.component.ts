import { Component } from '@angular/core';  
import { ROUTER_DIRECTIVES } from '@angular/router';

@Component({
  selector: 'my-app', 
  templateUrl: 'app/app.component.html',
  directives:[ ROUTER_DIRECTIVES ]
  
})
export class AppComponent {
  
}


/*
Copyright 2017 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://v2.angular.io/license
*/