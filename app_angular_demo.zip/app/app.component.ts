import { Component } from '@angular/core';

import { Account } from './account.model';

@Component({
  selector: 'my-app',
  templateUrl: 'app/app.component.html'
})
export class AppComponent {
  private _accounts:Array<Acccount> = [
  {
    id:1,
    title:'Bank Xyz',
    description:'This is main account',
    balance = 501.2
  } ,
  new Account(2,"Bank asd","My secret account",1024.10)
  ]
  private _nextId = 3;
  private createAcc(titleE1:any, descE1:any, balE1:any ){
    this._accounts.push(new Account(this._nextId,
              titleEl.value,
              descE1.value,
              balEl.value)
              )
    this._nextId++
    titleE1.value = ""
    descE1.value = ""
    balE1.value = 0
  }
  private removeAcc(index:number){
    this._accounts.splice(index, 1)
  }
  
}


/*
Copyright 2017 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://v2.angular.io/license
*/