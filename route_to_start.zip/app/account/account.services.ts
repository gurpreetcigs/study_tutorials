import {Injectable, Optional} from "@angular/core";
import {Account} from "./account.model";
import {LoggerService} from "../util/logger.services";


@Injectable()
export class AccountService{
   constructor(@Optional() private _logger:LoggerService){}
   private _accounts:Array<Account> = [
       new Account("1", "Globalbank", "Main Bank account","567"),
       new Account("1", "Indianbank", "Secondary account","300")
    ];
   public getAll():Promise<Array<Account>>{
       return Promise.resolve(this._accounts);
   }    
   private _nextId = 3;
   private _accountLimit = 3;
   public createAccount(newAccount:Account){
       
       
       return new Promise((resolve,reject) => {
          if(this._accounts.length >= this._accountLimit){
             return reject("Maximum number of accounts reached");
          }
          newAccount.id = this._nextId;
          if(this._logger){
             this._logger.log("Account Created "+newAccount.title);
          }
          this._accounts.push(newAccount);
          resolve(newAccount);
       });
       
   }
   public remove(index:number){
       this._accounts.splice(index,1);
       if(this._logger){
          this._logger.log("Account Deleted");
       }
   }
}

export let ACCOUNT_SERVICES_PROVIDERS:Array<any> = [ AccountService, LoggerService];