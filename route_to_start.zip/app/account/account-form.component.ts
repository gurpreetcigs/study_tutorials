import {Component, Output, EventEmitter, Input, ViewChild, ElementRef} from "@angular/core";
import {Account} from "./account.model";

@Component({
    selector : 'account-form',
    templateUrl: 'app/account/account-form.component.html' 
})

export class AccountForm{
    @Output() created = new EventEmitter<Account>();
    private createAcc(title:string, desc:string, balance:number ){
    var newAccount:Account = new Account(this._nextId,
              title.value,
              desc.value,
              balance.value);
    this.created.emit(newAccount);          
    title.value = "";
    desc.value = "";
    balance.value = 0;
    }
}