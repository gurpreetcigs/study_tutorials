import {Injectable} from "@amgular/core";
import {Account} from "./account/account.model";

@Injectable()
export class AccountService{
   private _accounts:Array<Account> = [
       new Account("1", "Globalbank", "Main Bank account","567"),
       new Account("1", "Indianbank", "Secondary account","300")
    ];
   public getAll:Array<Account>{
       return this._accounts;
   }    
   private _nextId = 3;
   public createAccount(newAccount:Account){
       _nextId++;
       this._accounts.push(newAccount);
   }
   public remove(index:number){
       this._accounts.splice(index,1);
   }
}