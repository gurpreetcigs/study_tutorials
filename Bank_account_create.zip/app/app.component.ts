import { Component } from '@angular/core';

import { Account } from './account.model';

@Component({
  selector: 'my-app',
  templateUrl: 'app/app.component.html'
})
export class AppComponent {
  private _accounts:Array<Acccount> = [
    new Account(1,"Bank of Baroda","My First account",500.10),
    new Account(2,"Bank asd","My secret account",1024.10) 
  ]
  private _nextId = 3;
  private createAcc(title:string, desc:string, balance:number ){
    this._accounts.push(new Account(this._nextId,
              title.value,
              desc.value,
              balance.value)
              );
    this._nextId++;
    title.value = "";
    desc.value = "";
    balance.value = 0;
  }
  private removeAcc(index:number){
    this._accounts.splice(index, 1)
  }
  
}


/*
Copyright 2017 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://v2.angular.io/license
*/