import {Component} from "@angular/core";

@Compoent({
    Selector : 'account-form',
    TemplateUrl: './app/account/account-form.component' 
})

export class AccountForm{
    
}